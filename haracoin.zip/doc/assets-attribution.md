<h2>Attribution</h2>

| Code/Icon  | Author | License |
| ------------- | ------------- | ------------- |
| src/strlcpy.h | Todd C. Miller <Todd.Miller@courtesan.com> | ISC |
| src/qt/res/icons/clock*.png, src/qt/res/icons/tx*.png, src/qt/res/src/*.svg | Wladimir van der Laan | MIT |
| src/qt/res/icons/address-book.png, src/qt/res/icons/export.png, src/qt/res/icons/history.png, src/qt/res/icons/key.png, src/qt/res/icons/lock_*.png, src/qt/res/icons/overview.png, src/qt/res/icons/receive.png, src/qt/res/icons/send.png, src/qt/res/icons/synced.png, src/qt/res/icons/filesave.png, pack: NUVOLA ICON THEME for KDE 3.x | David Vignoni (david@icon-king.com), ICON KING - www.icon-king.com | LGPL |
| src/qt/res/icons/connect*.png, Human-O2 | schollidesign | GNU/GPL |
| src/qt/res/icons/transaction*.png | md2k7 | ou are free to do with these icons as you wish, including selling, copying, modifying etc. |
| src/qt/res/icons/configure.png, src/qt/res/icons/quit.png, src/qt/res/icons/editcopy.png, src/qt/res/icons/editpaste.png, src/qt/res/icons/add.png, src/qt/res/icons/edit.png, src/qt/res/icons/remove.png (edited), pack: Crystal SVG | http://www.everaldo.com | LGPL |
| src/qt/res/icons/bitcoin.png, src/qt/res/icons/toolbar.png | Bitboy (optimized for 16x16 by Wladimir van der Laan) | Public Domain |
| scripts/img/reload.xcf (modified),src/qt/res/movies/update_spinner.mng, pack: Kids | Everaldo (Everaldo Coelho) | GNU/GPL |
| src/qt/res/images/splash2.jpg (Wallet image) | Crobbo (forum) | Public domain |
| HaraCoin Logo | Evan | Creative Commons Attribution 4.0 International License |
